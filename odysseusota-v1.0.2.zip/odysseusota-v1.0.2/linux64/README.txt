These linux executables have not been tested, use at own risk!
if there are any problems, please tell me (@tihmstar).
