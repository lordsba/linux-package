//
//  AppDelegate.h
//  mach-portal
//
//  Created by Kali on 2017/1/4.
//  Copyright © 2017年 Kali. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

