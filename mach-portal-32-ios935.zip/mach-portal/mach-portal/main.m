//
//  main.m
//  mach-portal
//
//  Created by Kali on 2017/1/4.
//  Copyright © 2017年 Kali. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
